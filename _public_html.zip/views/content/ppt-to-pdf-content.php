<!-- Intro Section -->

<!-- What Is Section -->
<section class="mb-5">
    <div class="card border-0 shadow-sm">
        <div class="card-body p-4">
            <h2 class="mb-3"><i class="fas fa-info-circle me-2 text-primary"></i>What is this PDF Tool?</h2>
            <p>This professional-grade PDF tool is designed to provide high-fidelity document management without the need for expensive software. It utilizes advanced cloud-based and local processing algorithms to ensure that your document's layout, fonts, and images are preserved with 100% accuracy. Whether you're a student, a legal professional, or a business owner, this tool streamlines your workflow by enabling instant modifications to your PDF files directly in your web browser.</p>
        </div>
    </div>
</section>
 <div class="card border-0 shadow-sm text-white mb-4" style="background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);">
 <div class="card-body p-4 p-md-5 text-center">
 <i class="fas fa-file-powerpoint fa-4x mb-3"></i>
 <h2 class="display-5 mb-3">📊 PPT to PDF Converter - Convert PowerPoint to PDF Online Free</h2>
 <p class="lead mb-0">Convert PowerPoint presentations (PPT, PPTX) to PDF instantly. Preserve all slides, formatting, and animations!</p>

<p class="text-center mt-3">Looking for more? Use our <a href="<?php echo $base_url; ?>dwg-to-pdf">Dwg To Pdf</a> and <a href="<?php echo $base_url; ?>pdf-to-jfif">Pdf To Jfif</a> for fast and accurate results.</p>
 </div>
 </div>

 <div class="container mb-5">
 <!-- Feature Cards -->
 <div class="row g-3 mb-4">
 <div class="col-md-3">
 <div class="card h-100 border-0 shadow-sm text-center feature-card">
 <div class="card-body">
 <i class="fas fa-bolt fa-3x text-primary mb-3"></i>
 <h6 class="fw-bold">Fast Conversion</h6>
 <p class="small mb-0">Seconds per presentation</p>
 </div>
 </div>
 </div>
 <div class="col-md-3">
 <div class="card h-100 border-0 shadow-sm text-center feature-card">
 <div class="card-body">
 <i class="fas fa-object-group fa-3x text-success mb-3"></i>
 <h6 class="fw-bold">All Slides</h6>
 <p class="small mb-0">Complete presentation</p>
 </div>
 </div>
 </div>
 <div class="col-md-3">
 <div class="card h-100 border-0 shadow-sm text-center feature-card">
 <div class="card-body">
 <i class="fas fa-expand fa-3x text-info mb-3"></i>
 <h6 class="fw-bold">Multiple Layouts</h6>
 <p class="small mb-0">Slides per page options</p>
 </div>
 </div>
 </div>
 <div class="col-md-3">
 <div class="card h-100 border-0 shadow-sm text-center feature-card">
 <div class="card-body">
 <i class="fas fa-shield-alt fa-3x text-warning mb-3"></i>
 <h6 class="fw-bold">Secure</h6>
 <p class="small mb-0">Auto-deletion in 1 hour</p>
 </div>
 </div>
 </div>
 </div>

 <!-- How It Works -->
 <div class="card border-0 shadow-sm mb-4">
 <div class="card-header bg-white border-0 py-3">
 <h3 class="h2 mb-0 text-center fw-bold"><i class="fas fa-cogs me-2 text-primary"></i>How to Convert PPT to PDF</h3>
 </div>
 <div class="card-body p-4 p-md-5">
 <p class="lead text-center mb-5">Convert PowerPoint to PDF in 3 simple steps.</p>
 
 <div class="row g-4">
 <div class="col-md-4">
 <div class="text-center mb-3">
 <div class="step-number mx-auto">1</div>
 </div>
 <div class="card border-0 shadow-sm h-100">
 <div class="card-body text-center">
 <i class="fas fa-upload fa-3x text-primary mb-3"></i>
 <h5 class="fw-bold">Upload PowerPoint</h5>
 <p class="small text-muted mb-0">Drag & drop or select PPT/PPTX file from your device.</p>
 </div>
 </div>
 </div>
 
 <div class="col-md-4">
 <div class="text-center mb-3">
 <div class="step-number mx-auto">2</div>
 </div>
 <div class="card border-0 shadow-sm h-100">
 <div class="card-body text-center">
 <i class="fas fa-cog fa-3x text-success mb-3"></i>
 <h5 class="fw-bold">Configure Layout</h5>
 <p class="small text-muted mb-0">Choose slides per page, orientation, quality settings.</p>
 </div>
 </div>
 </div>
 
 <div class="col-md-4">
 <div class="text-center mb-3">
 <div class="step-number mx-auto">3</div>
 </div>
 <div class="card border-0 shadow-sm h-100">
 <div class="card-body text-center">
 <i class="fas fa-download fa-3x text-info mb-3"></i>
 <h5 class="fw-bold">Download PDF</h5>
 <p class="small text-muted mb-0">Get converted PDF instantly. Ready to share!</p>
 </div>
 </div>
 </div>
 </div>
 </div>
 </div>

 <!-- Benefits -->
 <div class="card border-0 shadow-sm">
 <div class="card-header bg-white border-0 py-3">
 <h3 class="h2 mb-0 text-center fw-bold"><i class="fas fa-star me-2 text-warning"></i>Benefits</h3>
 </div>
 <div class="card-body p-4 p-md-5">
 <div class="row g-4">
 <div class="col-md-6">
 <h5 class="fw-bold text-primary mb-3">Why Convert PPT to PDF?</h5>
 <ul class="list-unstyled">
 <li class="mb-3">
 <i class="fas fa-check-circle benefit-check me-2"></i>
 <strong>Universal Access:</strong> Opens on any device without PowerPoint
 </li>
 <li class="mb-3">
 <i class="fas fa-check-circle benefit-check me-2"></i>
 <strong>Formatting Locked:</strong> Prevents accidental edits to slides
 </li>
 <li class="mb-3">
 <i class="fas fa-check-circle benefit-check me-2"></i>
 <strong>Email-Friendly:</strong> Smaller file size, easier attachment
 </li>
 <li class="mb-3">
 <i class="fas fa-check-circle benefit-check me-2"></i>
 <strong>Professional Sharing:</strong> Polished handouts for audiences
 </li>
 <li class="mb-3">
 <i class="fas fa-check-circle benefit-check me-2"></i>
 <strong>Print-Ready:</strong> Perfect formatting for printing services
 </li>
 </ul>
 </div>
 <div class="col-md-6">
 <h5 class="fw-bold text-success mb-3">Tool Features</h5>
 <ul class="list-unstyled">
 <li class="mb-3">
 <i class="fas fa-check-circle benefit-check me-2"></i>
 <strong>All Formats:</strong> PPT, PPTX, PPS, PPSX supported
 </li>
 <li class="mb-3">
 <i class="fas fa-check-circle benefit-check me-2"></i>
 <strong>Batch Processing:</strong> Convert multiple presentations at once
 </li>
 <li class="mb-3">
 <i class="fas fa-check-circle benefit-check me-2"></i>
 <strong>Layout Options:</strong> 1, 2, 3, 4, 6, 9 slides per page
 </li>
 <li class="mb-3">
 <i class="fas fa-check-circle benefit-check me-2"></i>
 <strong>Large Files:</strong> Handle presentations up to 100MB
 </li>
 <li class="mb-3">
 <i class="fas fa-check-circle benefit-check me-2"></i>
 <strong>100% Free:</strong> Unlimited conversions, no watermarks
 </li>
 </ul>
 </div>
 </div>
 
 <div class="text-center mt-4 p-4" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 15px;">
 <h4 class="text-white mb-3"><i class="fas fa-file-pdf me-2"></i>Convert PPT to PDF Now!</h4>
 <p class="text-white mb-0">Transform presentations instantly—free forever!</p>
 </div>
 </div>
 </div>
 </div>

 <!-- Bootstrap JS -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

